const dividir = function (a, b){
    if (b == 0) {
        return "No se puede dividir por 0"
    } else {
        return a / b
    }         
}

module.exports = dividir 
