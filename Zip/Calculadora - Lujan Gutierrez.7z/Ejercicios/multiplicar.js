const multiplicar = function (a, b){
    if ((a == 0)  || (b == 0)) {
        return 0
    } else {
        return a * b
    }     
}

module.exports = multiplicar
