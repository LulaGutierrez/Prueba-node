const restar = function (a, b){
    return a - b 
}

module.exports = restar

