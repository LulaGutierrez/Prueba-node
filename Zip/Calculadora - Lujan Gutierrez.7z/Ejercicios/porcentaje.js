const porcentaje = function (total, porcent){
    return (total * porcent) / 100
}

module.exports = porcentaje
